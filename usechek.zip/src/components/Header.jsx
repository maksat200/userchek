import { Link } from "react-router-dom";

const Header = () => (
  <header className="bg-blue-500 from-blue-600  p-4 text-white shadow-md">
    <div className="container mx-auto flex justify-between items-center">
      <Link to="/users" className="text-2xl font-bold">👥 UserApp</Link>
    </div>
  </header>
);

export default Header;
