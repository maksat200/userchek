import { useEffect, useState } from "react";
import { useParams, Link, useNavigate } from "react-router-dom";
import axios from "axios";

const UserDetails = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const [user, setUser] = useState(null);
  const [showPassword, setShowPassword] = useState(false);

  useEffect(() => {
    axios.get(`https://fakestoreapi.com/users/${id}`).then((response) => {
      setUser(response.data);
    });
  }, [id]);

  if (!user) return <p className="text-center mt-4">Загрузка...</p>;

  return (
    <div className="container mx-auto p-6 max-w-lg bg-white rounded-lg shadow-lg">
      <h2 className="text-3xl font-bold text-center mb-4">
        {user.name.firstname} {user.name.lastname}
      </h2>
      <div className="p-4 bg-gray-100 rounded-lg">
        <p className="text-gray-700"><strong>🏠 Адрес:</strong> {user.address.street}, {user.address.number}, {user.address.city}, {user.address.zipcode}</p>
        <p className="text-gray-700"><strong>📞 Телефон:</strong> {user.phone}</p>
        <p className="text-gray-700"><strong>🌍 Геолокация:</strong> {user.address.geolocation.lat}, {user.address.geolocation.long}</p>
        <p className="text-gray-700"><strong>🔐 Имя пользователя:</strong> {user.username}</p>
      </div>

      <div className="mt-4">
        <p className="text-gray-700">
          <strong>🔑 Пароль:</strong>  
          <span className={showPassword ? "text-gray-800" : "text-gray-400"}>
            {showPassword ? user.password : "••••••"}
          </span>
          <button
            onClick={() => setShowPassword(!showPassword)}
            className="ml-2 text-blue-500 hover:underline"
          >
            {showPassword ? "Скрыть" : "Показать"}
          </button>
        </p>
      </div>

      <button
        onClick={() => navigate('/users')}
        className="block w-full mt-4 bg-blue-600 text-white py-2 rounded-lg hover:bg-blue-700 transition"
      >
        ⬅️ Назад к списку пользователей
      </button>
    </div>
  );
};

export default UserDetails;
