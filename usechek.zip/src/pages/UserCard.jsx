import { Link } from 'react-router-dom';

const UserCard = ({ user }) => (
  <div className="p-4 bg-white rounded-xl shadow-md hover:scale-105 hover:shadow-lg transition-transform">
    <img src={`https://i.pravatar.cc/150?img=${user.id}`} alt="avatar" className="rounded-full w-24 h-24 mb-4 mx-auto" />
    <h2 className="text-lg font-bold">{user.name.firstname} {user.name.lastname}</h2>
    <p className="text-sm text-gray-600">{user.email}</p>
    <p className="text-sm text-gray-600">{user.address.city}, {user.address.street}</p>
    <Link to={`/user/${user.id}`} className="mt-4 block text-blue-600 hover:underline">Подробнее</Link>
  </div>
);

export default UserCard;