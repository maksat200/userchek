import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import axios from "axios";

const UserCard = ({ user }) => (
  <div className="p-6 bg-white rounded-lg shadow-lg transform transition-all hover:scale-105 hover:shadow-2xl">
    <img
      src={`https://i.pravatar.cc/150?img=${user.id}`}
      alt={user.name.firstname}
      className="w-20 h-20 rounded-full mx-auto border-4 border-blue-500"
    />
    <h3 className="text-xl font-semibold text-center mt-3">
      {user.name.firstname} {user.name.lastname}
    </h3>
    <p className="text-gray-500 text-center">{user.email}</p>
    <p className="text-gray-400 text-center text-sm">{user.address.city}, {user.address.street}</p>
    <Link
      to={`/user/${user.id}`}
      className="block mt-4 text-center bg-blue-600 text-white py-2 rounded-lg hover:bg-blue-700 transition"
    >
      Подробнее →
    </Link>
  </div>
);

const UserList = () => {
  const [users, setUsers] = useState([]);

  useEffect(() => {
    axios.get("https://fakestoreapi.com/users").then((response) => {
      setUsers(response.data);
    });
  }, []);

  return (
    <div className="container mx-auto p-6">
      <h1 className="text-3xl font-bold text-center mb-6">📋 Список пользователей</h1>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {users.map((user) => <UserCard key={user.id} user={user} />)}
      </div>
    </div>
  );
};

export default UserList;
