import { Link } from "react-router-dom";

const NotFound = () => (
  <div className="flex flex-col items-center justify-center h-screen text-center">
    <h1 className="text-9xl font-bold text-red-600 animate-bounce">404</h1>
    <p className="text-2xl mt-2">Страница не найдена</p>
    <Link to="/users" className="mt-4 bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700">
      Вернуться на главную
    </Link>
  </div>
);

export default NotFound;
